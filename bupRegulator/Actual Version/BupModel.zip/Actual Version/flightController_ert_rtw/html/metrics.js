function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtDW"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 261};
	 this.metricsArray.var["rtInf"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 8};
	 this.metricsArray.var["rtInfF"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 4};
	 this.metricsArray.var["rtM_"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 4};
	 this.metricsArray.var["rtMinusInf"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 8};
	 this.metricsArray.var["rtMinusInfF"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 4};
	 this.metricsArray.var["rtNaN"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 8};
	 this.metricsArray.var["rtNaNF"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 4};
	 this.metricsArray.var["rtU"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 130};
	 this.metricsArray.var["rtY"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 65};
	 this.metricsArray.fcn["acos"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["asin"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["atan2"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["ceil"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["cos"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["exp"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["flightController.c:Angle2Course"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["flightController.c:BimSupply"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["flightController.c:Control"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 31,
	stackTotal: 47};
	 this.metricsArray.fcn["flightController.c:TimeoutDecrement"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["flightController.c:checkFinalMane"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["flightController.c:errorCourseLimit"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["flightController.c:nonlinearCoefficientFunction"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["flightController.c:validateTarget"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 25,
	stackTotal: 41};
	 this.metricsArray.fcn["flightController.c:wherePoint"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["flightController_initialize"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 24};
	 this.metricsArray.fcn["flightController_step"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 180,
	stackTotal: 227};
	 this.metricsArray.fcn["floor"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmax"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmod"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtGetInf"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetInfF"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetMinusInf"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetMinusInfF"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetNaN"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetNaNF"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtIsInf"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsInfF"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsNaN"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsNaNF"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rt_InitInfAndNaN"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 24};
	 this.metricsArray.fcn["rt_atan2d_snf"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["rt_remd_snf"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["rt_roundd_snf"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["sin"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrt"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["trunc"] = {file: "D:\\seliverstov\\work\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="flightController_metrics.html">Global Memory: 496(bytes) Maximum Stack: 180(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
