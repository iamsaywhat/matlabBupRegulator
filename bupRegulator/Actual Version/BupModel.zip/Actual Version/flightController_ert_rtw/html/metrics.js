function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtDW"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 321};
	 this.metricsArray.var["rtInf"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 8};
	 this.metricsArray.var["rtInfF"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 4};
	 this.metricsArray.var["rtM_"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 4};
	 this.metricsArray.var["rtMinusInf"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 8};
	 this.metricsArray.var["rtMinusInfF"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 4};
	 this.metricsArray.var["rtNaN"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 8};
	 this.metricsArray.var["rtNaNF"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 4};
	 this.metricsArray.var["rtU"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 129};
	 this.metricsArray.var["rtY"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	size: 41};
	 this.metricsArray.fcn["acos"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["asin"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["atan2"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["ceil"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["cos"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["exp"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["flightController.c:Angle2Course"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["flightController.c:BimSupply"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["flightController.c:Control"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 31,
	stackTotal: 47};
	 this.metricsArray.fcn["flightController.c:TimeoutDecrement"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["flightController.c:checkFinalMane"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["flightController.c:errorCourseLimit"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["flightController.c:nonlinearCoefficientFunction"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["flightController.c:validateTarget"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 25,
	stackTotal: 41};
	 this.metricsArray.fcn["flightController.c:wherePoint"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["flightController_initialize"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 24};
	 this.metricsArray.fcn["flightController_step"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 152,
	stackTotal: 199};
	 this.metricsArray.fcn["floor"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmax"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmod"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtGetInf"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetInfF"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetMinusInf"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetMinusInfF"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetNaN"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetNaNF"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtIsInf"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsInfF"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsNaN"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsNaNF"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rt_InitInfAndNaN"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 24};
	 this.metricsArray.fcn["rt_atan2d_snf"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["rt_remd_snf"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["rt_roundd_snf"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["sin"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrt"] = {file: "D:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["trunc"] = {file: "C:\\Users\\tripl\\Desktop\\matlabProject\\bupRegulator\\Actual Version\\flightController_ert_rtw\\flightController.c",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="flightController_metrics.html">Global Memory: 531(bytes) Maximum Stack: 152(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
