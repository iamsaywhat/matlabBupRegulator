/*
 * File: flightController.h
 *
 * Code generated for Simulink model 'flightController'.
 *
 * Model version                  : 1.855
 * Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
 * C/C++ source code generated on : Tue Apr  7 21:55:05 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_flightController_h_
#define RTW_HEADER_flightController_h_
#include <stddef.h>
#include <float.h>
#include <math.h>
#ifndef flightController_COMMON_INCLUDES_
# define flightController_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* flightController_COMMON_INCLUDES_ */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

/* Block signals and states (default storage) for system '<Root>' */
typedef struct
{
  real_T targetPoint[4];               /* '<S1>/TargetSelector' */
  real_T TmpSignalConversionAtSFunctio_g[4];/* '<S1>/LogicController' */
  real_T touchdownPoint_Offset[4];     /* '<S1>/LogicController' */
  real_T initialPoint[4];              /* '<S1>/LogicController' */
  real_T windForce;                    /* '<S10>/Chart' */
  real_T windCourse;                   /* '<S10>/Chart' */
  real_T desiredCourse;                /* '<S1>/LogicController' */
  real_T LastPos_1_DSTATE;             /* '<S18>/LastPos' */
  real_T LastPos_2_DSTATE;             /* '<S18>/LastPos' */
  real_T PreviousBearing_DSTATE;       /* '<S21>/PreviousBearing' */
  real_T initialGroundSpeed;           /* '<S10>/Chart' */
  real_T currentGroundSpeed;           /* '<S10>/Chart' */
  real_T initialCourse;                /* '<S10>/Chart' */
  real_T currentCourse;                /* '<S10>/Chart' */
  real_T LastLineState;                /* '<S41>/BimTrigger' */
  real_T centralCourse;                /* '<S1>/LogicController' */
  real_T courseToTargetPoint;          /* '<S1>/LogicController' */
  uint32_T time;                       /* '<S1>/LogicController' */
  uint32_T timeout;                    /* '<S1>/LogicController' */
  uint32_T timeout_o;                  /* '<S1>/LogicController' */
  uint8_T enableTargetting;            /* '<S1>/LogicController' */
  uint8_T is_active_c5_flightController;/* '<S10>/Chart' */
  uint8_T is_c5_flightController;      /* '<S10>/Chart' */
  uint8_T is_active_c9_BupSimulinkLibrari;/* '<S41>/BimTrigger' */
  uint8_T is_active_c6_flightController;/* '<S1>/TargetSelector' */
  uint8_T is_c6_flightController;      /* '<S1>/TargetSelector' */
  uint8_T updateIndex;                 /* '<S1>/TargetSelector' */
  uint8_T is_active_c1_flightController;/* '<S1>/LogicController' */
  uint8_T is_active_Timer;             /* '<S1>/LogicController' */
  uint8_T is_Control;                  /* '<S1>/LogicController' */
  uint8_T is_active_Control;           /* '<S1>/LogicController' */
  uint8_T is_Flight;                   /* '<S1>/LogicController' */
  uint8_T was_Flight;                  /* '<S1>/LogicController' */
  uint8_T is_StepAngle;                /* '<S1>/LogicController' */
  uint8_T is_Touchdown;                /* '<S1>/LogicController' */
  uint8_T is_active_Touchdown;         /* '<S1>/LogicController' */
  uint8_T is_active_EventGenerator;    /* '<S1>/LogicController' */
  uint8_T is_BimSupply;                /* '<S1>/LogicController' */
  uint8_T is_active_BimSupply;         /* '<S1>/LogicController' */
  boolean_T DsblTg_DSTATE;             /* '<S10>/DsblTg' */
  boolean_T status;                    /* '<S1>/TargetSelector' */
  boolean_T side;                      /* '<S1>/LogicController' */
  boolean_T justReturnedHere;          /* '<S1>/LogicController' */
}
DW;

/* External inputs (root inport signals with default storage) */
typedef struct
{
  real_T touchdownPointLatitude;       /* '<Root>/touchdownPoint:Latitude' */
  real_T touchdownPointLongitude;      /* '<Root>/touchdownPoint:Longitude' */
  real_T touchdownPointAltitude;       /* '<Root>/touchdownPoint:Altitude' */
  real_T radioPointLatitude;           /* '<Root>/radioPoint:Latitude' */
  real_T radioPointLongitude;          /* '<Root>/radioPoint:Longitude' */
  real_T radioPointAltitude;           /* '<Root>/radioPoint:Altitude' */
  int16_T currentPointRelief;          /* '<Root>/currentPointRelief' */
  uint8_T currentPointReliefAvailable; /* '<Root>/currentReliefAvailable' */
  int16_T touchdownPointRelief;        /* '<Root>/touchdownPointRelief' */
  real_T currentPointLatitude;         /* '<Root>/currentPoint:Latitude' */
  real_T currentPointLongitude;        /* '<Root>/currentPoint:Longitude' */
  real_T currentPointAltitude;         /* '<Root>/currentPoint:Altitude' */
  real_T trackingCourse;               /* '<Root>/trackingCourse' */
  real_T velocityLatitude;             /* '<Root>/velocityLatitude' */
  real_T velocityLongitude;            /* '<Root>/velocityLongitude' */
  real_T velocityAltitude;             /* '<Root>/velocityAltitude' */
  real_T barometricAltitude;           /* '<Root>/barometricAltitude' */
  uint8_T barometricAvailable;         /* '<Root>/barometricAvailable' */
  int16_T radioPointRelief;            /* '<Root>/radioPointRelief' */
  uint8_T radioUpdateIndex;            /* '<Root>/radioUpdateIndex' */
  real_T barometricAirSpeed;           /* '<Root>/barometricAirSpeed' */
}
ExtU;

/* External outputs (root outports fed by signals with default storage) */
typedef struct
{
  real_T bimCommand;                   /* '<Root>/bimCommand' */
  uint8_T touchdown;                   /* '<Root>/touchdown' */
  real_T horizontalDistance;           /* '<Root>/horizontalDistance' */
  real_T onTargetTime;                 /* '<Root>/onTargetTime' */
  real_T touchdownTime;                /* '<Root>/touchdownTime' */
  int8_T bimSelect;                    /* '<Root>/bimSelect' */
  uint8_T bimForce;                    /* '<Root>/bimForce' */
}
ExtY;

/* Real-time Model Data Structure */
struct tag_RTM
{
  const char_T * volatile errorStatus;
};

/* Block signals and states (default storage) */
extern DW rtDW;

/* External inputs (root inport signals with default storage) */
extern ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY rtY;

/* Model entry point functions */
extern void flightController_initialize(void);
extern void flightController_step(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S3>/Display' : Unused code path elimination
 * Block '<S3>/Display1' : Unused code path elimination
 * Block '<S18>/Display' : Unused code path elimination
 * Block '<S18>/Display1' : Unused code path elimination
 * Block '<S22>/Gain' : Unused code path elimination
 * Block '<S23>/Gain' : Unused code path elimination
 * Block '<S18>/Scope1' : Unused code path elimination
 * Block '<S18>/Scope8' : Unused code path elimination
 * Block '<S18>/Scope9' : Unused code path elimination
 * Block '<S3>/Scope1' : Unused code path elimination
 * Block '<S3>/Scope2' : Unused code path elimination
 * Block '<S3>/Scope3' : Unused code path elimination
 * Block '<S1>/Display' : Unused code path elimination
 * Block '<S6>/Gain' : Unused code path elimination
 * Block '<S1>/Scope1' : Unused code path elimination
 * Block '<S1>/Scope2' : Unused code path elimination
 * Block '<S1>/Scope4' : Unused code path elimination
 * Block '<S1>/Scope5' : Unused code path elimination
 * Block '<S1>/Scope6' : Unused code path elimination
 * Block '<S1>/Scope7' : Unused code path elimination
 * Block '<S1>/Scope8' : Unused code path elimination
 * Block '<S1>/Scope9' : Unused code path elimination
 * Block '<S32>/Gain' : Unused code path elimination
 * Block '<S33>/Gain' : Unused code path elimination
 * Block '<S34>/Gain' : Unused code path elimination
 * Block '<S36>/Scope' : Unused code path elimination
 * Block '<S8>/Scope' : Unused code path elimination
 * Block '<S8>/Scope2' : Unused code path elimination
 * Block '<S8>/Scope5' : Unused code path elimination
 * Block '<S8>/Scope6' : Unused code path elimination
 * Block '<S8>/Scope7' : Unused code path elimination
 * Block '<S8>/Scope8' : Unused code path elimination
 * Block '<S9>/Scope' : Unused code path elimination
 * Block '<S10>/Scope2' : Unused code path elimination
 * Block '<S10>/SkipSolution' : Unused code path elimination
 * Block '<S3>/CourseSwitch' : Eliminated due to constant selection input
 * Block '<S18>/Manual Switch2' : Eliminated due to constant selection input
 * Block '<S3>/Manual Switch' : Eliminated due to constant selection input
 * Block '<S3>/Manual Switch1' : Eliminated due to constant selection input
 * Block '<S1>/TD_SysSwitch' : Eliminated due to constant selection input
 * Block '<S36>/Manual Switch' : Eliminated due to constant selection input
 * Block '<S1>/Constant' : Unused code path elimination
 * Block '<S3>/Constant1' : Unused code path elimination
 * Block '<S3>/Constant2' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('fullSystemModel/flightController')    - opens subsystem fullSystemModel/flightController
 * hilite_system('fullSystemModel/flightController/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'fullSystemModel'
 * '<S1>'   : 'fullSystemModel/flightController'
 * '<S2>'   : 'fullSystemModel/flightController/BimControllaNDriftCalc'
 * '<S3>'   : 'fullSystemModel/flightController/DataAnalyzer'
 * '<S4>'   : 'fullSystemModel/flightController/Degrees to Radians'
 * '<S5>'   : 'fullSystemModel/flightController/LogicController'
 * '<S6>'   : 'fullSystemModel/flightController/Radians to Degrees'
 * '<S7>'   : 'fullSystemModel/flightController/TargetSelector'
 * '<S8>'   : 'fullSystemModel/flightController/Targeting'
 * '<S9>'   : 'fullSystemModel/flightController/altitudeWeighting'
 * '<S10>'  : 'fullSystemModel/flightController/feedback'
 * '<S11>'  : 'fullSystemModel/flightController/BimControllaNDriftCalc/BimTriggers'
 * '<S12>'  : 'fullSystemModel/flightController/BimControllaNDriftCalc/DriftEstimator'
 * '<S13>'  : 'fullSystemModel/flightController/BimControllaNDriftCalc/PointMoventPlot'
 * '<S14>'  : 'fullSystemModel/flightController/BimControllaNDriftCalc/PreemptionTDP'
 * '<S15>'  : 'fullSystemModel/flightController/BimControllaNDriftCalc/BimTriggers/BimTrigger'
 * '<S16>'  : 'fullSystemModel/flightController/BimControllaNDriftCalc/PointMoventPlot/MATLAB Function'
 * '<S17>'  : 'fullSystemModel/flightController/BimControllaNDriftCalc/PreemptionTDP/MATLAB Function'
 * '<S18>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingCourse'
 * '<S19>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingSpeed'
 * '<S20>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingCourse/Azimuth'
 * '<S21>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingCourse/Bearing'
 * '<S22>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingCourse/Radians to Degrees1'
 * '<S23>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingCourse/Radians to Degrees2'
 * '<S24>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingCourse/Azimuth/Azimut'
 * '<S25>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingCourse/Bearing/Heading_true'
 * '<S26>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingSpeed/GPSVelocity'
 * '<S27>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingSpeed/ProjectionSpeed'
 * '<S28>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingSpeed/GPSVelocity/Velocity'
 * '<S29>'  : 'fullSystemModel/flightController/DataAnalyzer/InternalTrackingSpeed/ProjectionSpeed/Speed'
 * '<S30>'  : 'fullSystemModel/flightController/Targeting/ControlDemode'
 * '<S31>'  : 'fullSystemModel/flightController/Targeting/MATLAB Function'
 * '<S32>'  : 'fullSystemModel/flightController/Targeting/Radians to Degrees1'
 * '<S33>'  : 'fullSystemModel/flightController/Targeting/Radians to Degrees2'
 * '<S34>'  : 'fullSystemModel/flightController/Targeting/Radians to Degrees3'
 * '<S35>'  : 'fullSystemModel/flightController/Targeting/Radians to Degrees4'
 * '<S36>'  : 'fullSystemModel/flightController/Targeting/Roughening'
 * '<S37>'  : 'fullSystemModel/flightController/Targeting/TimeNAngleTurning'
 * '<S38>'  : 'fullSystemModel/flightController/Targeting/ControlDemode/ControlDemode'
 * '<S39>'  : 'fullSystemModel/flightController/Targeting/Roughening/DeadZone'
 * '<S40>'  : 'fullSystemModel/flightController/Targeting/Roughening/DeadZone/DeadZone'
 * '<S41>'  : 'fullSystemModel/flightController/feedback/BimTriggers'
 * '<S42>'  : 'fullSystemModel/flightController/feedback/Chart'
 * '<S43>'  : 'fullSystemModel/flightController/feedback/PointMoventPlot'
 * '<S44>'  : 'fullSystemModel/flightController/feedback/PreemptionTDP'
 * '<S45>'  : 'fullSystemModel/flightController/feedback/BimTriggers/BimTrigger'
 * '<S46>'  : 'fullSystemModel/flightController/feedback/PointMoventPlot/MATLAB Function'
 * '<S47>'  : 'fullSystemModel/flightController/feedback/PreemptionTDP/MATLAB Function'
 */

/*-
 * Requirements for '<Root>': flightController
 */
#endif                                 /* RTW_HEADER_flightController_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
