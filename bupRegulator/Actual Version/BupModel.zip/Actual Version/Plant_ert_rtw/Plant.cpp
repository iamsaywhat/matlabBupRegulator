//
// File: Plant.cpp
//
// Code generated for Simulink model 'Plant'.
//
// Model version                  : 1.893
// Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
// C/C++ source code generated on : Tue Jul 21 10:38:32 2020
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "Plant.h"
#define NumBitsPerChar                 8U

extern real_T rt_atan2d_snf(real_T u0, real_T u1);
extern real_T rt_remd_snf(real_T u0, real_T u1);
extern "C"
{
  extern real_T rtGetNaN(void);
  extern real32_T rtGetNaNF(void);
}                                      // extern "C"
  //===========*
  //  Constants *
  // ===========
#define RT_PI                          3.14159265358979323846
#define RT_PIF                         3.1415927F
#define RT_LN_10                       2.30258509299404568402
#define RT_LN_10F                      2.3025851F
#define RT_LOG10E                      0.43429448190325182765
#define RT_LOG10EF                     0.43429449F
#define RT_E                           2.7182818284590452354
#define RT_EF                          2.7182817F

//
//  UNUSED_PARAMETER(x)
//    Used to specify that a function parameter (argument) is required but not
//    accessed by the function body.

#ifndef UNUSED_PARAMETER
# if defined(__LCC__)
#   define UNUSED_PARAMETER(x)                                   // do nothing
# else

//
//  This is the semi-ANSI standard way of indicating that an
//  unused function parameter is required.

#   define UNUSED_PARAMETER(x)         (void) (x)
# endif
#endif

extern "C"
{
  extern real_T rtInf;
  extern real_T rtMinusInf;
  extern real_T rtNaN;
  extern real32_T rtInfF;
  extern real32_T rtMinusInfF;
  extern real32_T rtNaNF;
  extern void rt_InitInfAndNaN(size_t realSize);
  extern boolean_T rtIsInf(real_T value);
  extern boolean_T rtIsInfF(real32_T value);
  extern boolean_T rtIsNaN(real_T value);
  extern boolean_T rtIsNaNF(real32_T value);
  typedef struct
  {
    struct
    {
      uint32_T wordH;
      uint32_T wordL;
    }
    words;
  }
  BigEndianIEEEDouble;

  typedef struct
  {
    struct
    {
      uint32_T wordL;
      uint32_T wordH;
    }
    words;
  }
  LittleEndianIEEEDouble;

  typedef struct
  {
    union
    {
      real32_T wordLreal;
      uint32_T wordLuint;
    }
    wordL;
  }
  IEEESingle;
}                                      // extern "C"
extern "C"
{
  real_T rtInf;
  real_T rtMinusInf;
  real_T rtNaN;
  real32_T rtInfF;
  real32_T rtMinusInfF;
  real32_T rtNaNF;
}

extern "C"
{
  extern real_T rtGetInf(void);
  extern real32_T rtGetInfF(void);
  extern real_T rtGetMinusInf(void);
  extern real32_T rtGetMinusInfF(void);
}                                      // extern "C"
extern "C"
{
  //
  // Initialize rtNaN needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  real_T rtGetNaN(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T nan = 0.0;
    if (bitsPerReal == 32U)
    {
      nan = rtGetNaNF();
    }
    else
    {
      union
      {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      }
      tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF80000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      nan = tmpVal.fltVal;
    }

    return nan;
  }

  //
  // Initialize rtNaNF needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  real32_T rtGetNaNF(void)
  {
    IEEESingle nanF =
    {
      {
        0
      }
    };

    nanF.wordL.wordLuint = 0xFFC00000U;
    return nanF.wordL.wordLreal;
  }
}

extern "C"
{
  //
  // Initialize the rtInf, rtMinusInf, and rtNaN needed by the
  // generated code. NaN is initialized as non-signaling. Assumes IEEE.
  //
  void rt_InitInfAndNaN(size_t realSize)
  {
    (void) (realSize);
    rtNaN = rtGetNaN();
    rtNaNF = rtGetNaNF();
    rtInf = rtGetInf();
    rtInfF = rtGetInfF();
    rtMinusInf = rtGetMinusInf();
    rtMinusInfF = rtGetMinusInfF();
  }

  // Test if value is infinite
  boolean_T rtIsInf(real_T value)
  {
    return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
  }

  // Test if single-precision value is infinite
  boolean_T rtIsInfF(real32_T value)
  {
    return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
  }

  // Test if value is not a number
  boolean_T rtIsNaN(real_T value)
  {
    return (boolean_T)((value!=value) ? 1U : 0U);
  }

  // Test if single-precision value is not a number
  boolean_T rtIsNaNF(real32_T value)
  {
    return (boolean_T)(((value!=value) ? 1U : 0U));
  }
}

extern "C"
{
  //
  // Initialize rtInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  real_T rtGetInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T inf = 0.0;
    if (bitsPerReal == 32U)
    {
      inf = rtGetInfF();
    }
    else
    {
      union
      {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      }
      tmpVal;

      tmpVal.bitVal.words.wordH = 0x7FF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      inf = tmpVal.fltVal;
    }

    return inf;
  }

  //
  // Initialize rtInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  real32_T rtGetInfF(void)
  {
    IEEESingle infF;
    infF.wordL.wordLuint = 0x7F800000U;
    return infF.wordL.wordLreal;
  }

  //
  // Initialize rtMinusInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  real_T rtGetMinusInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T minf = 0.0;
    if (bitsPerReal == 32U)
    {
      minf = rtGetMinusInfF();
    }
    else
    {
      union
      {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      }
      tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      minf = tmpVal.fltVal;
    }

    return minf;
  }

  //
  // Initialize rtMinusInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  real32_T rtGetMinusInfF(void)
  {
    IEEESingle minfF;
    minfF.wordL.wordLuint = 0xFF800000U;
    return minfF.wordL.wordLreal;
  }
}

void PlantModelClass::Plant_reset()
{
  // Outputs for Atomic SubSystem: '<Root>/Plant'
  // Outputs for Atomic SubSystem: '<S1>/ResetFunction'
  // StateWriter: '<S6>/State Writer' incorporates:
  //   Constant: '<S6>/Constant1'

  rtDW.x_integrator_DSTATE = 0.0;

  // StateWriter: '<S6>/State Writer1' incorporates:
  //   Constant: '<S6>/Constant2'

  rtDW.y_integrator_DSTATE = 0.0;

  // StateWriter: '<S6>/State Writer3' incorporates:
  //   Constant: '<S6>/Constant4'

  rtDW.timer_integrator_DSTATE = 0.0;

  // StateWriter: '<S6>/State Writer6' incorporates:
  //   Constant: '<S6>/Constant7'

  rtDW.WindXintegrator_DSTATE = 0.0;

  // StateWriter: '<S6>/State Writer7' incorporates:
  //   Constant: '<S6>/Constant8'

  rtDW.WindYintegrator_DSTATE = 0.0;

  // End of Outputs for SubSystem: '<S1>/ResetFunction'
  // End of Outputs for SubSystem: '<Root>/Plant'
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T u0_0;
  int32_T u1_0;
  if (rtIsNaN(u0) || rtIsNaN(u1))
  {
    y = (rtNaN);
  }
  else if (rtIsInf(u0) && rtIsInf(u1))
  {
    if (u0 > 0.0)
    {
      u0_0 = 1;
    }
    else
    {
      u0_0 = -1;
    }

    if (u1 > 0.0)
    {
      u1_0 = 1;
    }
    else
    {
      u1_0 = -1;
    }

    y = atan2((real_T)u0_0, (real_T)u1_0);
  }
  else if (u1 == 0.0)
  {
    if (u0 > 0.0)
    {
      y = RT_PI / 2.0;
    }
    else if (u0 < 0.0)
    {
      y = -(RT_PI / 2.0);
    }
    else
    {
      y = 0.0;
    }
  }
  else
  {
    y = atan2(u0, u1);
  }

  return y;
}

real_T rt_remd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T u1_0;
  if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf(u1)))))
  {
    y = (rtNaN);
  }
  else
  {
    if (u1 < 0.0)
    {
      u1_0 = std::ceil(u1);
    }
    else
    {
      u1_0 = std::floor(u1);
    }

    if ((u1 != 0.0) && (u1 != u1_0))
    {
      u1_0 = std::abs(u0 / u1);
      if (std::abs(u1_0 - std::floor(u1_0 + 0.5)) <= DBL_EPSILON * u1_0)
      {
        y = 0.0 * u0;
      }
      else
      {
        y = std::fmod(u0, u1);
      }
    }
    else
    {
      y = std::fmod(u0, u1);
    }
  }

  return y;
}

// Model step function
void PlantModelClass::step()
{
  real_T fi1;
  real_T fi2;
  real_T delta_la;
  real_T fi1_0;
  real_T fi2_0;
  real_T delta_la_0;
  real_T rtb_Sum;
  real_T rtb_Sum1_a;
  real_T rtb_Pos_alt;
  boolean_T rtb_Compare;
  real_T rtb_Gain1_p;
  real_T rtb_Pos_lon;
  real_T rtb_Pos_alt_l;
  real_T rtb_y_g;
  real_T rtb_Sum1_j;
  real_T rtb_TmpSignalConversionAtSFun_0;
  real_T rtb_TmpSignalConversionAtSFun_1;

  // Outputs for Atomic SubSystem: '<Root>/Plant'
  // RelationalOperator: '<S2>/Compare' incorporates:
  //   Constant: '<S2>/Constant'
  //   Inport: '<Root>/TD_CMD'

  rtb_Compare = (rtU.TD_CMD <= 0);

  // DiscreteIntegrator: '<S1>/angle_integrator' incorporates:
  //   Constant: '<S7>/Constant'
  //   Gain: '<S7>/Gain'
  //   Inport: '<Root>/InitCourse'
  //   Sum: '<S7>/Sum3'

  if (rtDW.angle_integrator_IC_LOADING != 0)
  {
    rtDW.angle_integrator_DSTATE = -(rtU.InitCourse - 90.0);
  }

  // Gain: '<S3>/Gain1' incorporates:
  //   DiscreteIntegrator: '<S1>/angle_integrator'

  rtb_Gain1_p = 0.017453292519943295 * rtDW.angle_integrator_DSTATE;

  // Sum: '<S14>/Sum' incorporates:
  //   DiscreteIntegrator: '<S1>/y_integrator'
  //   DiscreteIntegrator: '<S9>/WindYintegrator'
  //   Gain: '<S14>/Gain1'
  //   Gain: '<S14>/Gain6'
  //   Inport: '<Root>/Initial_lat'
  //   Sum: '<S4>/Sum1'

  rtb_Sum = (rtDW.y_integrator_DSTATE + rtDW.WindYintegrator_DSTATE) * 0.001 *
    0.009 + rtU.Initial_lat;

  // Sum: '<S14>/Sum1' incorporates:
  //   DiscreteIntegrator: '<S1>/x_integrator'
  //   DiscreteIntegrator: '<S9>/WindXintegrator'
  //   Gain: '<S14>/Gain'
  //   Gain: '<S14>/Gain5'
  //   Gain: '<S26>/Gain1'
  //   Inport: '<Root>/Initial_lon'
  //   Product: '<S14>/Divide'
  //   Sum: '<S4>/Sum'
  //   Trigonometry: '<S14>/Trigonometric Function2'

  rtb_Sum1_a = (rtDW.x_integrator_DSTATE + rtDW.WindXintegrator_DSTATE) * 0.001 *
    0.009 / std::cos(0.017453292519943295 * rtb_Sum) + rtU.Initial_lon;

  // Sum: '<S1>/Sum' incorporates:
  //   DiscreteIntegrator: '<S1>/timer_integrator'
  //   Gain: '<S1>/Vv'
  //   Inport: '<Root>/Initial_alt'

  rtb_Pos_alt = rtU.Initial_alt - 8.0 * rtDW.timer_integrator_DSTATE;

  // Memory: '<S10>/LastPos'
  rtb_TmpSignalConversionAtSFun_1 = rtDW.LastPos_1_PreviousInput;
  rtb_Pos_lon = rtDW.LastPos_2_PreviousInput;

  // Outputs for Atomic SubSystem: '<S10>/Azimuth'
  // MATLAB Function: '<S15>/Azimut' incorporates:
  //   SignalConversion: '<S17>/TmpSignal ConversionAt SFunction Inport2'

  //  u0 - ����� �������
  //  u1 - �������� �����
  //  la - �������
  //  fi - ������
  // MATLAB Function 'Azimuth/Azimut': '<S17>:1'
  // '<S17>:1:6' la1 = u0(2)*pi/180;
  // '<S17>:1:7' fi1 = u0(1)*pi/180;
  fi1 = rtb_TmpSignalConversionAtSFun_1 * 3.1415926535897931 / 180.0;

  // '<S17>:1:8' la2 = u1(2)*pi/180;
  // '<S17>:1:9' fi2 = u1(1)*pi/180;
  fi2 = rtb_Sum * 3.1415926535897931 / 180.0;

  // '<S17>:1:10' delta_la = la2-la1;
  delta_la = rtb_Sum1_a * 3.1415926535897931 / 180.0 - rtb_Pos_lon *
    3.1415926535897931 / 180.0;

  // End of Outputs for SubSystem: '<S10>/Azimuth'

  // Outputs for Atomic SubSystem: '<S10>/Bearing'
  // MATLAB Function: '<S16>/Heading_true' incorporates:
  //   Delay: '<S16>/PreviousBearing'
  //   SignalConversion: '<S18>/TmpSignal ConversionAt SFunction Inport1'

  // '<S17>:1:11' y = atan2(sin(delta_la)*cos(fi2), cos(fi1)*sin(fi2)-sin(fi1)*cos(fi2)*cos(delta_la)); 
  // '<S17>:1:12' y = rem((y + 2*pi), 2*pi);
  //  ���������, ��� ���������� ����������
  // MATLAB Function 'Bearing/Heading_true': '<S18>:1'
  // '<S18>:1:3' un = u1 - u0;
  rtb_TmpSignalConversionAtSFun_0 = rtb_Sum - rtb_TmpSignalConversionAtSFun_1;
  rtb_TmpSignalConversionAtSFun_1 = rtb_Sum1_a - rtb_Pos_lon;

  // '<S18>:1:4' d_lat = un(1);
  // '<S18>:1:5' d_lon = un(2);
  //  ������� ��� ����������� ����������� ���� � ������ ��������� �����
  //  ����������� 0 � 180 �� �������
  // '<S18>:1:8' if d_lon > 180
  if (rtb_TmpSignalConversionAtSFun_1 > 180.0)
  {
    // '<S18>:1:9' d_lon = d_lon - 360;
    rtb_TmpSignalConversionAtSFun_1 -= 360.0;
  }
  else
  {
    if (rtb_TmpSignalConversionAtSFun_1 < -180.0)
    {
      // '<S18>:1:10' elseif d_lon < (-180)
      // '<S18>:1:11' d_lon = d_lon +360;
      rtb_TmpSignalConversionAtSFun_1 += 360.0;
    }
  }

  //  ������ �����
  // '<S18>:1:14' un_pow1 = d_lat*d_lat;
  rtb_Pos_lon = rtb_TmpSignalConversionAtSFun_0 *
    rtb_TmpSignalConversionAtSFun_0;

  // '<S18>:1:15' un_pow2 = d_lon*d_lon;
  rtb_Pos_alt_l = rtb_TmpSignalConversionAtSFun_1 *
    rtb_TmpSignalConversionAtSFun_1;

  // '<S18>:1:16' if (un_pow1 < 1e-16) && (un_pow2 < 1e-16)
  if ((rtb_Pos_lon < 1.0E-16) && (rtb_Pos_alt_l < 1.0E-16))
  {
    // '<S18>:1:17' y = last_y;
    rtb_y_g = rtDW.PreviousBearing_DSTATE_b;
  }
  else
  {
    // '<S18>:1:18' else
    // '<S18>:1:19' x = acos( d_lon / (sqrt(un_pow2 + un_pow1)));
    // '<S18>:1:20' y = acos( d_lat / (sqrt(un_pow2 + un_pow1)));
    rtb_Sum1_j = std::sqrt(rtb_Pos_alt_l + rtb_Pos_lon);
    rtb_y_g = std::acos(rtb_TmpSignalConversionAtSFun_0 / rtb_Sum1_j);

    // '<S18>:1:21' if x > pi/2
    if (std::acos(rtb_TmpSignalConversionAtSFun_1 / rtb_Sum1_j) >
        1.5707963267948966)
    {
      // '<S18>:1:22' y = 2*pi - y;
      rtb_y_g = 6.2831853071795862 - rtb_y_g;
    }
  }

  // End of MATLAB Function: '<S16>/Heading_true'

  // Update for Delay: '<S16>/PreviousBearing'
  rtDW.PreviousBearing_DSTATE_b = rtb_y_g;

  // End of Outputs for SubSystem: '<S10>/Bearing'

  // Sum: '<S13>/Sum' incorporates:
  //   DiscreteIntegrator: '<S1>/y_integrator'
  //   Gain: '<S13>/Gain1'
  //   Gain: '<S13>/Gain6'
  //   Inport: '<Root>/Initial_lat'

  rtb_y_g = 0.001 * rtDW.y_integrator_DSTATE * 0.009 + rtU.Initial_lat;

  // Sum: '<S13>/Sum1' incorporates:
  //   DiscreteIntegrator: '<S1>/x_integrator'
  //   Gain: '<S13>/Gain'
  //   Gain: '<S13>/Gain5'
  //   Gain: '<S25>/Gain1'
  //   Inport: '<Root>/Initial_lon'
  //   Product: '<S13>/Divide'
  //   Trigonometry: '<S13>/Trigonometric Function2'

  rtb_Sum1_j = 0.001 * rtDW.x_integrator_DSTATE * 0.009 / std::cos
    (0.017453292519943295 * rtb_y_g) + rtU.Initial_lon;

  // Outputs for Atomic SubSystem: '<S11>/Azimuth'
  // MATLAB Function: '<S19>/Azimut' incorporates:
  //   Memory: '<S11>/LastPos'
  //   SignalConversion: '<S21>/TmpSignal ConversionAt SFunction Inport1'

  //  u0 - ����� �������
  //  u1 - �������� �����
  //  la - �������
  //  fi - ������
  // MATLAB Function 'Azimuth/Azimut': '<S21>:1'
  // '<S21>:1:6' la1 = u0(2)*pi/180;
  // '<S21>:1:7' fi1 = u0(1)*pi/180;
  fi1_0 = rtDW.LastPos_PreviousInput[0] * 3.1415926535897931 / 180.0;

  // '<S21>:1:8' la2 = u1(2)*pi/180;
  // '<S21>:1:9' fi2 = u1(1)*pi/180;
  fi2_0 = rtb_y_g * 3.1415926535897931 / 180.0;

  // '<S21>:1:10' delta_la = la2-la1;
  delta_la_0 = rtb_Sum1_j * 3.1415926535897931 / 180.0 -
    rtDW.LastPos_PreviousInput[1] * 3.1415926535897931 / 180.0;

  // End of Outputs for SubSystem: '<S11>/Azimuth'

  // Outputs for Atomic SubSystem: '<S11>/Bearing'
  // MATLAB Function: '<S20>/Heading_true' incorporates:
  //   Delay: '<S20>/PreviousBearing'
  //   Memory: '<S11>/LastPos'
  //   SignalConversion: '<S22>/TmpSignal ConversionAt SFunction Inport1'

  // '<S21>:1:11' y = atan2(sin(delta_la)*cos(fi2), cos(fi1)*sin(fi2)-sin(fi1)*cos(fi2)*cos(delta_la)); 
  // '<S21>:1:12' y = rem((y + 2*pi), 2*pi);
  //  ���������, ��� ���������� ����������
  // MATLAB Function 'Bearing/Heading_true': '<S22>:1'
  // '<S22>:1:3' un = u1 - u0;
  rtb_TmpSignalConversionAtSFun_0 = rtb_y_g - rtDW.LastPos_PreviousInput[0];
  rtb_TmpSignalConversionAtSFun_1 = rtb_Sum1_j - rtDW.LastPos_PreviousInput[1];

  // '<S22>:1:4' d_lat = un(1);
  // '<S22>:1:5' d_lon = un(2);
  //  ������� ��� ����������� ����������� ���� � ������ ��������� �����
  //  ����������� 0 � 180 �� �������
  // '<S22>:1:8' if d_lon > 180
  if (rtb_TmpSignalConversionAtSFun_1 > 180.0)
  {
    // '<S22>:1:9' d_lon = d_lon - 360;
    rtb_TmpSignalConversionAtSFun_1 -= 360.0;
  }
  else
  {
    if (rtb_TmpSignalConversionAtSFun_1 < -180.0)
    {
      // '<S22>:1:10' elseif d_lon < (-180)
      // '<S22>:1:11' d_lon = d_lon +360;
      rtb_TmpSignalConversionAtSFun_1 += 360.0;
    }
  }

  //  ������ �����
  // '<S22>:1:14' un_pow1 = d_lat*d_lat;
  rtb_Pos_lon = rtb_TmpSignalConversionAtSFun_0 *
    rtb_TmpSignalConversionAtSFun_0;

  // '<S22>:1:15' un_pow2 = d_lon*d_lon;
  rtb_Pos_alt_l = rtb_TmpSignalConversionAtSFun_1 *
    rtb_TmpSignalConversionAtSFun_1;

  // '<S22>:1:16' if (un_pow1 < 1e-16) && (un_pow2 < 1e-16)
  if ((rtb_Pos_lon < 1.0E-16) && (rtb_Pos_alt_l < 1.0E-16))
  {
    // '<S22>:1:17' y = last_y;
    rtb_TmpSignalConversionAtSFun_0 = rtDW.PreviousBearing_DSTATE;
  }
  else
  {
    // '<S22>:1:18' else
    // '<S22>:1:19' x = acos( d_lon / (sqrt(un_pow2 + un_pow1)));
    // '<S22>:1:20' y = acos( d_lat / (sqrt(un_pow2 + un_pow1)));
    rtb_Pos_lon = std::sqrt(rtb_Pos_alt_l + rtb_Pos_lon);
    rtb_TmpSignalConversionAtSFun_0 = std::acos(rtb_TmpSignalConversionAtSFun_0 /
      rtb_Pos_lon);

    // '<S22>:1:21' if x > pi/2
    if (std::acos(rtb_TmpSignalConversionAtSFun_1 / rtb_Pos_lon) >
        1.5707963267948966)
    {
      // '<S22>:1:22' y = 2*pi - y;
      rtb_TmpSignalConversionAtSFun_0 = 6.2831853071795862 -
        rtb_TmpSignalConversionAtSFun_0;
    }
  }

  // End of MATLAB Function: '<S20>/Heading_true'

  // Update for Delay: '<S20>/PreviousBearing'
  rtDW.PreviousBearing_DSTATE = rtb_TmpSignalConversionAtSFun_0;

  // End of Outputs for SubSystem: '<S11>/Bearing'

  // Outputs for Atomic SubSystem: '<S12>/GPSVelocity'
  // SignalConversion: '<S24>/TmpSignal ConversionAt SFunction Inport2' incorporates:
  //   MATLAB Function: '<S23>/Velocity'
  //   Memory: '<S12>/LastPos'

  rtb_TmpSignalConversionAtSFun_0 = rtDW.LastPos_1_PreviousInput_e;
  rtb_Pos_lon = rtDW.LastPos_2_PreviousInput_g;
  rtb_Pos_alt_l = rtDW.LastPos_3_PreviousInput_n;

  // End of Outputs for SubSystem: '<S12>/GPSVelocity'

  // Gain: '<S27>/Gain1' incorporates:
  //   Constant: '<S28>/Constant'
  //   Gain: '<S28>/Gain'
  //   Inport: '<Root>/WindAngle'
  //   Sum: '<S28>/Sum3'

  // MATLAB Function 'GPSVelocity/Velocity': '<S24>:1'
  // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  //
  //    GPSPos2Speed - ����������� �������� �� �������� GPS
  //    u1 - ����� ������������, ������� ������� ����������� (lat, lon, alt)
  //    u0 - ����� �� ������� ���������� ����������� (lat, lon, alt)
  //    time - ����� ����� �������� ���������
  //
  // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  // '<S24>:1:10' un = u1-u0;
  // '<S24>:1:11' v_lat = un(1)*40000/360*1000/time;
  // '<S24>:1:12' v_lon = un(2)*(40000/360*1000/time * cos(pi/180*u0(1)));
  // '<S24>:1:13' v_alt = un(3);
  rtb_TmpSignalConversionAtSFun_1 = -(rtU.WindAngle - 90.0) *
    0.017453292519943295;

  // Update for DiscreteIntegrator: '<S1>/angle_integrator' incorporates:
  //   Gain: '<S1>/AngleSpeed'
  //   Gain: '<S1>/Inv'
  //   Inport: '<Root>/leftStrap'
  //   Inport: '<Root>/rightStrap'
  //   Sum: '<S1>/Sum1'

  rtDW.angle_integrator_IC_LOADING = 0U;
  rtDW.angle_integrator_DSTATE += -((rtU.rightStrap - rtU.leftStrap) * 0.14);

  // Update for DiscreteIntegrator: '<S1>/y_integrator' incorporates:
  //   Gain: '<S1>/Vh2'
  //   Product: '<S1>/Product1'
  //   Trigonometry: '<S1>/Trigonometric Function'

  rtDW.y_integrator_DSTATE += 20.0 * std::sin(rtb_Gain1_p) * (real_T)rtb_Compare;

  // Update for DiscreteIntegrator: '<S9>/WindYintegrator' incorporates:
  //   Inport: '<Root>/WindSpeed'
  //   Product: '<S9>/Product1'
  //   Trigonometry: '<S9>/Trigonometric Function3'

  rtDW.WindYintegrator_DSTATE += std::sin(rtb_TmpSignalConversionAtSFun_1) *
    rtU.WindSpeed;

  // Update for DiscreteIntegrator: '<S1>/x_integrator' incorporates:
  //   Gain: '<S1>/Vh1'
  //   Product: '<S1>/Product2'
  //   Trigonometry: '<S1>/Trigonometric Function1'

  rtDW.x_integrator_DSTATE += 20.0 * std::cos(rtb_Gain1_p) * (real_T)rtb_Compare;

  // Update for DiscreteIntegrator: '<S9>/WindXintegrator' incorporates:
  //   Inport: '<Root>/WindSpeed'
  //   Product: '<S9>/Product2'
  //   Trigonometry: '<S9>/Trigonometric Function2'

  rtDW.WindXintegrator_DSTATE += std::cos(rtb_TmpSignalConversionAtSFun_1) *
    rtU.WindSpeed;

  // Update for DiscreteIntegrator: '<S1>/timer_integrator' incorporates:
  //   Constant: '<S1>/SampleTime'

  rtDW.timer_integrator_DSTATE++;

  // Update for Memory: '<S10>/LastPos'
  rtDW.LastPos_1_PreviousInput = rtb_Sum;
  rtDW.LastPos_2_PreviousInput = rtb_Sum1_a;

  // Update for Memory: '<S11>/LastPos'
  rtDW.LastPos_PreviousInput[0] = rtb_y_g;
  rtDW.LastPos_PreviousInput[1] = rtb_Sum1_j;
  rtDW.LastPos_PreviousInput[2] = rtb_Pos_alt;

  // Update for Memory: '<S12>/LastPos'
  rtDW.LastPos_1_PreviousInput_e = rtb_Sum;
  rtDW.LastPos_2_PreviousInput_g = rtb_Sum1_a;
  rtDW.LastPos_3_PreviousInput_n = rtb_Pos_alt;

  // End of Outputs for SubSystem: '<Root>/Plant'

  // Outport: '<Root>/Pos_lat'
  rtY.Pos_lat = rtb_Sum;

  // Outport: '<Root>/Pos_lon'
  rtY.Pos_lon = rtb_Sum1_a;

  // Outport: '<Root>/Pos_alt'
  rtY.Pos_alt = rtb_Pos_alt;

  // Outputs for Atomic SubSystem: '<Root>/Plant'
  // Outport: '<Root>/SWS_Height' incorporates:
  //   Constant: '<S8>/Constant'
  //   Sum: '<S8>/Sum3'

  rtY.SWS_Height = 20.0 + rtb_Pos_alt;

  // Outputs for Atomic SubSystem: '<S11>/Azimuth'
  // Outport: '<Root>/HeadingTrue' incorporates:
  //   MATLAB Function: '<S19>/Azimut'

  rtY.HeadingTrue = rt_remd_snf(rt_atan2d_snf(std::sin(delta_la_0) * std::cos
    (fi2_0), std::cos(fi1_0) * std::sin(fi2_0) - std::sin(fi1_0) * std::cos
    (fi2_0) * std::cos(delta_la_0)) + 6.2831853071795862, 6.2831853071795862);

  // End of Outputs for SubSystem: '<S11>/Azimuth'

  // Outputs for Atomic SubSystem: '<S12>/GPSVelocity'
  // Outport: '<Root>/VelLatitude' incorporates:
  //   MATLAB Function: '<S23>/Velocity'
  //   SignalConversion: '<S24>/TmpSignal ConversionAt SFunction Inport1'

  rtY.VelLatitude = (rtb_Sum - rtb_TmpSignalConversionAtSFun_0) * 40000.0 /
    360.0 * 1000.0;

  // Outport: '<Root>/VelLongitude' incorporates:
  //   MATLAB Function: '<S23>/Velocity'
  //   SignalConversion: '<S24>/TmpSignal ConversionAt SFunction Inport1'

  rtY.VelLongitude = std::cos(0.017453292519943295 *
    rtb_TmpSignalConversionAtSFun_0) * 111111.11111111111 * (rtb_Sum1_a -
    rtb_Pos_lon);

  // Outport: '<Root>/VelAltitude' incorporates:
  //   MATLAB Function: '<S23>/Velocity'
  //   SignalConversion: '<S24>/TmpSignal ConversionAt SFunction Inport1'

  rtY.VelAltitude = rtb_Pos_alt - rtb_Pos_alt_l;

  // End of Outputs for SubSystem: '<S12>/GPSVelocity'

  // Outputs for Atomic SubSystem: '<S10>/Azimuth'
  // Outport: '<Root>/Course' incorporates:
  //   MATLAB Function: '<S15>/Azimut'

  rtY.Course = rt_remd_snf(rt_atan2d_snf(std::sin(delta_la) * std::cos(fi2), std::
    cos(fi1) * std::sin(fi2) - std::sin(fi1) * std::cos(fi2) * std::cos(delta_la))
    + 6.2831853071795862, 6.2831853071795862);

  // End of Outputs for SubSystem: '<S10>/Azimuth'
  // End of Outputs for SubSystem: '<Root>/Plant'
}

// Model initialize function
void PlantModelClass::initialize()
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // ConstCode for Outport: '<Root>/SWS_TrueSpeed' incorporates:
  //   Constant: '<S8>/Constant1'

  rtY.SWS_TrueSpeed = 20.0;

  // ConstCode for Outport: '<Root>/SWS_InstrumentalSpeed' incorporates:
  //   Constant: '<S8>/Constant2'

  rtY.SWS_InstrumentalSpeed = 20.0;

  // SystemInitialize for Atomic SubSystem: '<Root>/Plant'
  // InitializeConditions for DiscreteIntegrator: '<S1>/angle_integrator'
  rtDW.angle_integrator_IC_LOADING = 1U;

  // End of SystemInitialize for SubSystem: '<Root>/Plant'
}

// Constructor
PlantModelClass::PlantModelClass()
{
}

// Destructor
PlantModelClass::~PlantModelClass()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL * PlantModelClass::getRTM()
{
  return (&rtM);
}

//
// File trailer for generated code.
//
// [EOF]
//
