function CodeDefine() { 
this.def = new Array();
this.def["rtObj"] = {file: "ert_main_cpp.html",line:22,type:"var"};
this.def["rt_OneStep"] = {file: "ert_main_cpp.html",line:36,type:"fcn"};
this.def["main"] = {file: "ert_main_cpp.html",line:74,type:"fcn"};
this.def["BigEndianIEEEDouble"] = {file: "Plant_cpp.html",line:79,type:"type"};
this.def["LittleEndianIEEEDouble"] = {file: "Plant_cpp.html",line:90,type:"type"};
this.def["IEEESingle"] = {file: "Plant_cpp.html",line:101,type:"type"};
this.def["rtInf"] = {file: "Plant_cpp.html",line:105,type:"var"};
this.def["rtMinusInf"] = {file: "Plant_cpp.html",line:106,type:"var"};
this.def["rtNaN"] = {file: "Plant_cpp.html",line:107,type:"var"};
this.def["rtInfF"] = {file: "Plant_cpp.html",line:108,type:"var"};
this.def["rtMinusInfF"] = {file: "Plant_cpp.html",line:109,type:"var"};
this.def["rtNaNF"] = {file: "Plant_cpp.html",line:110,type:"var"};
this.def["rtGetNaN"] = {file: "Plant_cpp.html",line:126,type:"fcn"};
this.def["rtGetNaNF"] = {file: "Plant_cpp.html",line:155,type:"fcn"};
this.def["rt_InitInfAndNaN"] = {file: "Plant_cpp.html",line:175,type:"fcn"};
this.def["rtIsInf"] = {file: "Plant_cpp.html",line:187,type:"fcn"};
this.def["rtIsInfF"] = {file: "Plant_cpp.html",line:193,type:"fcn"};
this.def["rtIsNaN"] = {file: "Plant_cpp.html",line:199,type:"fcn"};
this.def["rtIsNaNF"] = {file: "Plant_cpp.html",line:205,type:"fcn"};
this.def["rtGetInf"] = {file: "Plant_cpp.html",line:217,type:"fcn"};
this.def["rtGetInfF"] = {file: "Plant_cpp.html",line:246,type:"fcn"};
this.def["rtGetMinusInf"] = {file: "Plant_cpp.html",line:257,type:"fcn"};
this.def["rtGetMinusInfF"] = {file: "Plant_cpp.html",line:286,type:"fcn"};
this.def["Plant_reset"] = {file: "Plant_cpp.html",line:294,type:"fcn"};
this.def["rt_atan2d_snf"] = {file: "Plant_cpp.html",line:327,type:"fcn"};
this.def["rt_remd_snf"] = {file: "Plant_cpp.html",line:381,type:"fcn"};
this.def["step"] = {file: "Plant_cpp.html",line:422,type:"fcn"};
this.def["initialize"] = {file: "Plant_cpp.html",line:872,type:"fcn"};
this.def["getRTM"] = {file: "Plant_cpp.html",line:908,type:"fcn"};
this.def["RT_MODEL"] = {file: "Plant_h.html",line:38,type:"type"};
this.def["DW"] = {file: "Plant_h.html",line:59,type:"type"};
this.def["ExtU"] = {file: "Plant_h.html",line:74,type:"type"};
this.def["ExtY"] = {file: "Plant_h.html",line:91,type:"type"};
this.def["rtU"] = {file: "Plant_h.html",line:105,type:"var"};
this.def["int8_T"] = {file: "rtwtypes_h.html",line:49,type:"type"};
this.def["uint8_T"] = {file: "rtwtypes_h.html",line:50,type:"type"};
this.def["int16_T"] = {file: "rtwtypes_h.html",line:51,type:"type"};
this.def["uint16_T"] = {file: "rtwtypes_h.html",line:52,type:"type"};
this.def["int32_T"] = {file: "rtwtypes_h.html",line:53,type:"type"};
this.def["uint32_T"] = {file: "rtwtypes_h.html",line:54,type:"type"};
this.def["real32_T"] = {file: "rtwtypes_h.html",line:55,type:"type"};
this.def["real64_T"] = {file: "rtwtypes_h.html",line:56,type:"type"};
this.def["real_T"] = {file: "rtwtypes_h.html",line:62,type:"type"};
this.def["time_T"] = {file: "rtwtypes_h.html",line:63,type:"type"};
this.def["boolean_T"] = {file: "rtwtypes_h.html",line:64,type:"type"};
this.def["int_T"] = {file: "rtwtypes_h.html",line:65,type:"type"};
this.def["uint_T"] = {file: "rtwtypes_h.html",line:66,type:"type"};
this.def["ulong_T"] = {file: "rtwtypes_h.html",line:67,type:"type"};
this.def["char_T"] = {file: "rtwtypes_h.html",line:68,type:"type"};
this.def["uchar_T"] = {file: "rtwtypes_h.html",line:69,type:"type"};
this.def["byte_T"] = {file: "rtwtypes_h.html",line:70,type:"type"};
this.def["pointer_T"] = {file: "rtwtypes_h.html",line:88,type:"type"};
}
CodeDefine.instance = new CodeDefine();
var testHarnessInfo = {OwnerFileName: "", HarnessOwner: "", HarnessName: "", IsTestHarness: "0"};
var relPathToBuildDir = "../ert_main.c";
var fileSep = "\\";
var isPC = true;
function Html2SrcLink() {
	this.html2SrcPath = new Array;
	this.html2Root = new Array;
	this.html2SrcPath["ert_main_cpp.html"] = "../ert_main.cpp";
	this.html2Root["ert_main_cpp.html"] = "ert_main_cpp.html";
	this.html2SrcPath["Plant_cpp.html"] = "../Plant.cpp";
	this.html2Root["Plant_cpp.html"] = "Plant_cpp.html";
	this.html2SrcPath["Plant_h.html"] = "../Plant.h";
	this.html2Root["Plant_h.html"] = "Plant_h.html";
	this.html2SrcPath["rtwtypes_h.html"] = "../rtwtypes.h";
	this.html2Root["rtwtypes_h.html"] = "rtwtypes_h.html";
	this.getLink2Src = function (htmlFileName) {
		 if (this.html2SrcPath[htmlFileName])
			 return this.html2SrcPath[htmlFileName];
		 else
			 return null;
	}
	this.getLinkFromRoot = function (htmlFileName) {
		 if (this.html2Root[htmlFileName])
			 return this.html2Root[htmlFileName];
		 else
			 return null;
	}
}
Html2SrcLink.instance = new Html2SrcLink();
var fileList = [
"ert_main_cpp.html","Plant_cpp.html","Plant_h.html","rtwtypes_h.html"];
