//
// File: Plant.h
//
// Code generated for Simulink model 'Plant'.
//
// Model version                  : 1.893
// Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
// C/C++ source code generated on : Tue Jul 21 10:38:32 2020
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#ifndef RTW_HEADER_Plant_h_
#define RTW_HEADER_Plant_h_
#include <stddef.h>
#include <cmath>
#include <float.h>
#include <math.h>
#ifndef Plant_COMMON_INCLUDES_
# define Plant_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 // Plant_COMMON_INCLUDES_

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

// Forward declaration for rtModel
typedef struct tag_RTM RT_MODEL;

// Block signals and states (default storage) for system '<Root>'
typedef struct
{
  real_T LastPos_PreviousInput[3];     // '<S11>/LastPos'
  real_T angle_integrator_DSTATE;      // '<S1>/angle_integrator'
  real_T y_integrator_DSTATE;          // '<S1>/y_integrator'
  real_T WindYintegrator_DSTATE;       // '<S9>/WindYintegrator'
  real_T x_integrator_DSTATE;          // '<S1>/x_integrator'
  real_T WindXintegrator_DSTATE;       // '<S9>/WindXintegrator'
  real_T timer_integrator_DSTATE;      // '<S1>/timer_integrator'
  real_T PreviousBearing_DSTATE;       // '<S20>/PreviousBearing'
  real_T PreviousBearing_DSTATE_b;     // '<S16>/PreviousBearing'
  real_T LastPos_1_PreviousInput;      // '<S10>/LastPos'
  real_T LastPos_2_PreviousInput;      // '<S10>/LastPos'
  real_T LastPos_1_PreviousInput_e;    // '<S12>/LastPos'
  real_T LastPos_2_PreviousInput_g;    // '<S12>/LastPos'
  real_T LastPos_3_PreviousInput_n;    // '<S12>/LastPos'
  uint8_T angle_integrator_IC_LOADING; // '<S1>/angle_integrator'
}
DW;

// External inputs (root inport signals with default storage)
typedef struct
{
  real_T rightStrap;                   // '<Root>/rightStrap'
  real_T leftStrap;                    // '<Root>/leftStrap'
  uint8_T TD_CMD;                      // '<Root>/TD_CMD'
  real_T WindSpeed;                    // '<Root>/WindSpeed'
  real_T WindAngle;                    // '<Root>/WindAngle'
  real_T InitCourse;                   // '<Root>/InitCourse'
  real_T Initial_lat;                  // '<Root>/Initial_lat'
  real_T Initial_lon;                  // '<Root>/Initial_lon'
  real_T Initial_alt;                  // '<Root>/Initial_alt'
}
ExtU;

// External outputs (root outports fed by signals with default storage)
typedef struct
{
  real_T Pos_lat;                      // '<Root>/Pos_lat'
  real_T Pos_lon;                      // '<Root>/Pos_lon'
  real_T Pos_alt;                      // '<Root>/Pos_alt'
  real_T SWS_Height;                   // '<Root>/SWS_Height'
  real_T SWS_TrueSpeed;                // '<Root>/SWS_TrueSpeed'
  real_T SWS_InstrumentalSpeed;        // '<Root>/SWS_InstrumentalSpeed'
  real_T HeadingTrue;                  // '<Root>/HeadingTrue'
  real_T VelLatitude;                  // '<Root>/VelLatitude'
  real_T VelLongitude;                 // '<Root>/VelLongitude'
  real_T VelAltitude;                  // '<Root>/VelAltitude'
  real_T Course;                       // '<Root>/Course'
}
ExtY;

// Real-time Model Data Structure
struct tag_RTM
{
  const char_T * volatile errorStatus;
};

// Class declaration for model Plant
class PlantModelClass
{
  // public data and function members
 public:
  // External inputs
  ExtU rtU;

  // External outputs
  ExtY rtY;

  // model initialize function
  void initialize();

  // model event function
  void Plant_reset();

  // model step function
  void step();

  // Constructor
  PlantModelClass();

  // Destructor
  ~PlantModelClass();

  // Real-Time Model get method
  RT_MODEL * getRTM();

  // private data and function members
 private:
  // Block signals and states
  DW rtDW;

  // Real-Time Model
  RT_MODEL rtM;
};

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S10>/Display' : Unused code path elimination
//  Block '<S10>/Display1' : Unused code path elimination
//  Block '<S10>/Scope1' : Unused code path elimination
//  Block '<S10>/Scope8' : Unused code path elimination
//  Block '<S10>/Scope9' : Unused code path elimination
//  Block '<S11>/Display' : Unused code path elimination
//  Block '<S11>/Display1' : Unused code path elimination
//  Block '<S11>/Scope1' : Unused code path elimination
//  Block '<S11>/Scope8' : Unused code path elimination
//  Block '<S11>/Scope9' : Unused code path elimination
//  Block '<S1>/Scope' : Unused code path elimination
//  Block '<S1>/Scope1' : Unused code path elimination
//  Block '<S1>/Scope2' : Unused code path elimination
//  Block '<S1>/Scope3' : Unused code path elimination
//  Block '<S1>/Scope4' : Unused code path elimination
//  Block '<S1>/Scope7' : Unused code path elimination
//  Block '<S10>/Manual Switch2' : Eliminated due to constant selection input
//  Block '<S11>/Manual Switch2' : Eliminated due to constant selection input


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Note that this particular code originates from a subsystem build,
//  and has its own system numbers different from the parent model.
//  Refer to the system hierarchy for this subsystem below, and use the
//  MATLAB hilite_system command to trace the generated code back
//  to the parent model.  For example,
//
//  hilite_system('fullSystemModel/Plant')    - opens subsystem fullSystemModel/Plant
//  hilite_system('fullSystemModel/Plant/Kp') - opens and selects block Kp
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'fullSystemModel'
//  '<S1>'   : 'fullSystemModel/Plant'
//  '<S2>'   : 'fullSystemModel/Plant/Compare To Zero'
//  '<S3>'   : 'fullSystemModel/Plant/Degrees to Radians'
//  '<S4>'   : 'fullSystemModel/Plant/GNSS'
//  '<S5>'   : 'fullSystemModel/Plant/InitializeFunction'
//  '<S6>'   : 'fullSystemModel/Plant/ResetFunction'
//  '<S7>'   : 'fullSystemModel/Plant/RotateOnNorth'
//  '<S8>'   : 'fullSystemModel/Plant/SWS'
//  '<S9>'   : 'fullSystemModel/Plant/WindCreator'
//  '<S10>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse'
//  '<S11>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse1'
//  '<S12>'  : 'fullSystemModel/Plant/GNSS/TrackingSpeed'
//  '<S13>'  : 'fullSystemModel/Plant/GNSS/Transformation'
//  '<S14>'  : 'fullSystemModel/Plant/GNSS/Transformation1'
//  '<S15>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse/Azimuth'
//  '<S16>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse/Bearing'
//  '<S17>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse/Azimuth/Azimut'
//  '<S18>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse/Bearing/Heading_true'
//  '<S19>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse1/Azimuth'
//  '<S20>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse1/Bearing'
//  '<S21>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse1/Azimuth/Azimut'
//  '<S22>'  : 'fullSystemModel/Plant/GNSS/InternalTrackingCourse1/Bearing/Heading_true'
//  '<S23>'  : 'fullSystemModel/Plant/GNSS/TrackingSpeed/GPSVelocity'
//  '<S24>'  : 'fullSystemModel/Plant/GNSS/TrackingSpeed/GPSVelocity/Velocity'
//  '<S25>'  : 'fullSystemModel/Plant/GNSS/Transformation/Degrees to Radians'
//  '<S26>'  : 'fullSystemModel/Plant/GNSS/Transformation1/Degrees to Radians'
//  '<S27>'  : 'fullSystemModel/Plant/WindCreator/Degrees to Radians1'
//  '<S28>'  : 'fullSystemModel/Plant/WindCreator/RotateOnNorth'


//-
//  Requirements for '<Root>': Plant

#endif                                 // RTW_HEADER_Plant_h_

//
// File trailer for generated code.
//
// [EOF]
//
